#pragma once

#include <glm/glm.hpp>

#include "BufferObject.h"
#include "VertexArrayObject.h"

// Parametrikus fel�letek absztrakt oszt�lya
class ParametricSurface
{
	VertexArrayObject	m_vao;
	IndexBuffer			m_gpuBufferIndices;
	ArrayBuffer			m_gpuBufferPos;
	ArrayBuffer			m_gpuBufferNormal;
	ArrayBuffer			m_gpuBufferTex;

	int m_num_indices;

public:
	void Init(int N = 30, int M = 30);

	void Draw();

protected:
	// Virtu�lis met�dus a text�rakoordin�t�k kisz�m�t�s�hoz.
	virtual glm::vec2 GetTexCoord(float u, float v) const;

	// Absztrakt met�dus a parametrikus fel�let egy pontj�nak kisz�m�t�s�hoz.
	virtual glm::vec3 GetPos(float u, float v) const = 0;

	// Norm�lissz�m�t�s numerikus differenci�l�s seg�ts�g�vel.
	virtual glm::vec3 GetNorm(float u, float v) const;
};


// Parametrikus s�kdarabka
class ParametricPlane : public ParametricSurface
{
	glm::vec3 GetPos(float u, float v) const
	{
		return glm::vec3(u * 2 - 1, 0, v * 2 - 1);
	}
};


// Parametrikus g�mbfel�let
class ParametricSphere : public ParametricSurface
{
	float m_radius;

public:
	ParametricSphere(float radius = 1.0f)
		: m_radius(radius)
	{}

	glm::vec3 GetPos(float u, float v) const
	{
		// orig� k�z�ppont�, egys�gsugar� g�mb parametrikus alakja: http://hu.wikipedia.org/wiki/G%C3%B6mb#Egyenletek 
		// figyelj�nk:	matematik�ban sokszor a Z tengely mutat felfel�, de n�lunk az Y, teh�t a legt�bb k�plethez k�pest n�lunk
		//				az Y �s Z koordin�t�k felcser�lve szerepelnek
		u *= 2 * 3.141592654f;
		v *= 3.141592654f;

		float
			cu = cosf(u),
			su = sinf(u),
			cv = cosf(v),
			sv = sinf(v);

		float r = 2;

		return glm::vec3(r*cu*sv, r*cv, r*su*sv);
	}
};

// Parametrikus f�lg�mbfel�let
class ParametricHemiSphere : public ParametricSurface
{
	float m_radius;

public:
	ParametricHemiSphere(float radius = 1.0f)
		: m_radius(radius)
	{}

	glm::vec3 GetPos(float u, float v) const
	{
		// orig� k�z�ppont�, egys�gsugar� g�mb parametrikus alakja: http://hu.wikipedia.org/wiki/G%C3%B6mb#Egyenletek 
		// figyelj�nk:	matematik�ban sokszor a Z tengely mutat felfel�, de n�lunk az Y, teh�t a legt�bb k�plethez k�pest n�lunk
		//				az Y �s Z koordin�t�k felcser�lve szerepelnek
		u *= 2*3.141592654f;
		v *= 3.141592654f/2;

		float
			cu = cosf(u),
			su = sinf(u),
			cv = cosf(v),
			sv = sinf(v);

		return glm::vec3(cu*sv, cv, su*sv) * m_radius;
	}
};

// Parametrikus hengerpal�st
class ParametricCylinder : public ParametricSurface
{
	float m_height;
	float m_radius;

public:
	ParametricCylinder(float height = 1.0f, float radius = 1.0f) 
		: m_height(height), m_radius(radius)
	{}

	glm::vec3 GetPos(float u, float v) const
	{
		u *= m_height;
		v *= 2 * 3.141592654f;

		float cv = cosf(v), sv = sinf(v);
		float r = 2;

		return glm::vec3(m_radius*cv, u, m_radius*sv);
	}
};


// Parametrikus t�rusz
class ParametricTorus : public ParametricSurface
{
	float m_R;
	float m_r;

public:
	ParametricTorus(float R = 2.0f, float r = 0.5f)
		: m_R(R), m_r(r)
	{}

	glm::vec3 GetPos(float u, float v) const
	{
		u *= 2 * 3.141592654f;
		v *= 2 * 3.141592654f;

		float 
			cu = cosf(u),
			su = sinf(u), 
			cv = cosf(v),
			sv = sinf(v);

		// https://hu.wikipedia.org/wiki/T%C3%B3rusz
		return glm::vec3(
			(m_R + m_r*cv) * cu,
			(m_R + m_r*cv) * su,
			       m_r*sv);
	}
};


class ParametricLufikakok : public ParametricSurface
{
	glm::vec3 GetPos(float u, float v) const
	{
		float r = 2;

		u *= 2 * 3.141592654f;
		v *= 2 * 3.141592654f;

		float
			cu = cosf(u),
			su = sinf(u),
			cv = cosf(v),
			sv = sinf(v);

		auto normal = glm::vec3(cu*sv, cv, su*sv);

		return r * normal *
			std::pow(
				std::max({ normal.x, normal.y, normal.z }), 3);
	}
};

// Parametrikus k�ppal�st
class ParametricCone : public ParametricSurface
{
	float m_height;
	float m_radius;

public:
	ParametricCone(float height = 1.0f, float radius = 1.0f)
		: m_height(height), m_radius(radius)
	{}

	glm::vec3 GetPos(float u, float v) const
	{
		v *= 2 * 3.141592654f;

		float cv = cosf(v), sv = sinf(v);
		float r = 2;

		return glm::vec3(m_radius*cv, m_height, m_radius*sv)*u;
	}
};


// Parametrikus k�rlap
class ParametricDisc : public ParametricSurface
{
	float m_radius;

public:
	ParametricDisc(float radius = 1.0f)
		: m_radius(radius)
	{}

	glm::vec3 GetPos(float u, float v) const
	{
		v *= 2 * 3.141592654f;

		float cv = cosf(v), sv = sinf(v);
		float r = 2;

		return glm::vec3(cv, 0, sv)*u*m_radius;
	}
};