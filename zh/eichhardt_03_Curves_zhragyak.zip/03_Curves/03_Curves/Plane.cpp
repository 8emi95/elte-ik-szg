#include "Plane.h"

#include <SDL_opengl.h>

void Plane::Init()
{
	m_gpuBufferPos.BufferData(
		std::vector<glm::vec3>{
		//		  X, Y, Z
		glm::vec3(-1, 0, -1),
		glm::vec3(-1, 0, 1),
		glm::vec3(1, 0, -1),
		glm::vec3(1, 0, 1)
	}
	);

	m_gpuBufferNormal.BufferData(
		std::vector<glm::vec3>{
		// normal.X,.Y,.Z
		glm::vec3(0, 1, 0), // 0
		glm::vec3(0, 1, 0), // 1
		glm::vec3(0, 1, 0), // 2
		glm::vec3(0, 1, 0)  // 3
	}
	);

	m_gpuBufferTex.BufferData(
		std::vector<glm::vec2>{
		//        u, v
		glm::vec2(0, 0), // 0
		glm::vec2(1, 0), // 1
		glm::vec2(0, 1), // 2
		glm::vec2(1, 1)	 // 3
	}
	);

	m_gpuBufferIndices.BufferData(
		std::vector<int>{
		0, 1, 2,
		2, 1, 3	
	}
	);

	m_vao.Init(
	{
		{ CreateAttribute<0, glm::vec3, 0, sizeof(glm::vec3)>, m_gpuBufferPos },
		{ CreateAttribute<1, glm::vec3, 0, sizeof(glm::vec3)>, m_gpuBufferNormal },
		{ CreateAttribute<2, glm::vec2, 0, sizeof(glm::vec2)>, m_gpuBufferTex }
	},
		m_gpuBufferIndices
	);
}

void Plane::Draw()
{
	m_vao.Bind();
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
	m_vao.Unbind();
}