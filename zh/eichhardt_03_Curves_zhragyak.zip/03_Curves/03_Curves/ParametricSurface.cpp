#include "ParametricSurface.h"

void ParametricSurface::Init(int N, int M)
{
	m_num_indices = 3 * 2 * (N)*(M);

	//
	// geometria letrehozasa
	//

	// NxM darab n�gysz�ggel k�zel�tj�k a parametrikus fel�let�nket => (N+1)x(M+1) pontban kell ki�rt�kelni
	std::vector<glm::vec3> positions((N + 1)*(M + 1));
	std::vector<glm::vec3> normals((N + 1)*(M + 1));
	std::vector<glm::vec2> texcoords((N + 1)*(M + 1));
	for (int i = 0; i <= N; ++i)
		for (int j = 0; j <= M; ++j)
		{
			float u = i / (float)N;
			float v = j / (float)M;

			auto idx = i + j*(N + 1);
			positions[idx] = GetPos(u, v);
			normals[idx] = GetNorm(u, v);
			texcoords[idx] = GetTexCoord(u, v);
		}

	m_gpuBufferPos.BufferData(positions);
	m_gpuBufferNormal.BufferData(normals);
	m_gpuBufferTex.BufferData(texcoords);

	// indexpuffer adatai: NxM n�gysz�g = 2xNxM h�romsz�g = h�romsz�glista eset�n 3x2xNxM index
	std::vector<GLushort> indices(m_num_indices);
	for (int i = 0; i<N; ++i)
		for (int j = 0; j<M; ++j)
		{
			// minden n�gysz�gre csin�ljunk kett� h�romsz�get, amelyek a k�vetkez� 
			// (i,j) indexekn�l sz�letett (u_i, v_i) param�ter�rt�kekhez tartoz�
			// pontokat k�tik �ssze:
			//
			//		(i,j+1)
			//		  o-----o(i+1,j+1)
			//		  |\    |			a = p(u_i, v_i)
			//		  | \   |			b = p(u_{i+1}, v_i)
			//		  |  \  |			c = p(u_i, v_{i+1})
			//		  |   \ |			d = p(u_{i+1}, v_{i+1})
			//		  |	   \|
			//	(i,j) o-----o(i+1, j)
			//
			// - az (i,j)-hez tart�z� 1D-s index a VBO-ban: i+j*(N+1)
			// - az (i,j)-hez tart�z� 1D-s index az IB-ben: i*6+j*6*(N+1) 
			//		(mert minden n�gysz�gh�z 2db h�romsz�g = 6 index tartozik)
			//
			indices[6 * i + j * 3 * 2 * (N)+0] = (i)+(j)*	(N + 1);
			indices[6 * i + j * 3 * 2 * (N)+1] = (i + 1) + (j)*	(N + 1);
			indices[6 * i + j * 3 * 2 * (N)+2] = (i)+(j + 1)*(N + 1);
			indices[6 * i + j * 3 * 2 * (N)+3] = (i + 1) + (j)*	(N + 1);
			indices[6 * i + j * 3 * 2 * (N)+4] = (i + 1) + (j + 1)*(N + 1);
			indices[6 * i + j * 3 * 2 * (N)+5] = (i)+(j + 1)*(N + 1);
		}

	m_gpuBufferIndices.BufferData(indices);

	m_vao.Init(
	{
		{ CreateAttribute<0, glm::vec3, 0, sizeof(glm::vec3)>, m_gpuBufferPos },
		{ CreateAttribute<1, glm::vec3, 0, sizeof(glm::vec3)>, m_gpuBufferNormal },
		{ CreateAttribute<2, glm::vec2, 0, sizeof(glm::vec2)>, m_gpuBufferTex }
	},
		m_gpuBufferIndices
	);
}

void ParametricSurface::Draw()
{
	m_vao.Bind();
	glDrawElements(GL_TRIANGLES, m_num_indices, GL_UNSIGNED_SHORT, 0);
	m_vao.Unbind();
}

glm::vec2 ParametricSurface::GetTexCoord(float u, float v) const
{
	return glm::vec2(u, v);
}

glm::vec3 ParametricSurface::GetNorm(float u, float v) const
{
	float eps = 0.01;
	glm::vec3 du = GetPos(u + eps, v) - GetPos(u - eps, v);
	glm::vec3 dv = GetPos(u, v + eps) - GetPos(u, v - eps);

	return glm::normalize(glm::cross(du, dv));
}