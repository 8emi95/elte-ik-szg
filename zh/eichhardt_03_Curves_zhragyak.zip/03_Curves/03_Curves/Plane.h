#pragma once

#include <glm/glm.hpp>

#include "BufferObject.h"
#include "VertexArrayObject.h"

class Plane
{
	VertexArrayObject	m_vao;
	IndexBuffer			m_gpuBufferIndices;
	ArrayBuffer			m_gpuBufferPos;
	ArrayBuffer			m_gpuBufferNormal;
	ArrayBuffer			m_gpuBufferTex;

public:
	void Init();

	void Draw();
};