#include <osg/Texture2D>
#include <osg/Geometry>
#include <osgDB/WriteFile>
#include <osgViewer/Viewer>
#include <osg/MatrixTransform>
#include <osgDB/ReadFile>

#ifdef _DEBUG
#pragma comment(lib, "osgd.lib")
#pragma comment(lib, "osgDBd.lib")
#pragma comment(lib, "osgViewerd.lib")
#else
#pragma comment(lib, "osg.lib")
#pragma comment(lib, "osgDB.lib")
#pragma comment(lib, "osgViewer.lib")
#endif

#pragma warning(disable : 4482 )

template<typename F, typename Fn, typename Ft>
void calc(float x, float y,
	osg::ref_ptr<osg::Vec3Array>& vertices,
	osg::ref_ptr<osg::Vec3Array>& normals,
	osg::ref_ptr<osg::Vec2Array>& texcoords,
	F f, Fn fn, Ft ft)
{
	vertices->push_back(f(x,y));
	normals->push_back(fn(x,y));
	texcoords->push_back(ft(x,y));
}

template<typename F, typename Fn, typename Ft>
osg::ref_ptr<osg::Geode> getParam(F f, Fn fn, Ft ft)
{
	// poz�ci�k
	osg::ref_ptr<osg::Vec3Array> vertices = new osg::Vec3Array;
	osg::ref_ptr<osg::Vec3Array> normals = new osg::Vec3Array;
	osg::ref_ptr<osg::Vec2Array> texcoords = new osg::Vec2Array;

	const int N = 8;
	float delta = 1.0 / N;
	for (int i = 0; i<N; ++i) {
		for (int j = 0; j<N; ++j) {
			float x = i*delta;
			float y = j*delta;
			// 1. h�romsz�g: x,y x+delta,y y+delta,x
			calc(x, y, vertices, normals, texcoords, f, fn, ft);
			calc(x, y + delta, vertices, normals, texcoords, f, fn, ft);
			calc(x + delta, y, vertices, normals, texcoords, f, fn, ft);
			// 2. h�romsz�g: x+delta,y x+delta,y+delta y+de, f, fn, ftlta,x
			calc(x + delta, y, vertices, normals, texcoords, f, fn, ft);
			calc(x, y + delta, vertices, normals, texcoords, f, fn, ft);
			calc(x + delta, y + delta, vertices, normals, texcoords, f, fn, ft);
		}
	}

	// n�gysz�g geometria
	osg::ref_ptr<osg::Geometry> quad = new osg::Geometry;
	quad->setUseVertexBufferObjects(true);

	// �ll�tsuk be, hogy a VBO-ba milyen adatok ker�ljenek
	quad->setVertexArray(vertices.get());
	quad->setNormalArray(normals.get());
	quad->setNormalBinding(osg::Geometry::BIND_PER_VERTEX);
	quad->setTexCoordArray(0, texcoords.get());
	// kirajzoland� primit�v meghat�roz�sa
	quad->addPrimitiveSet(new osg::DrawArrays(GL_TRIANGLES, 0, 6 * N*N));

	// text�ra bet�lt�se
	osg::ref_ptr<osg::Texture2D> texture = new osg::Texture2D;
	osg::ref_ptr<osg::Image> image = osgDB::readImageFile("Images/land_shallow_topo_2048.jpg");
	texture->setImage(image.get());
	texture->setFilter(osg::Texture::FilterParameter::MIN_FILTER, osg::Texture::FilterMode::LINEAR_MIPMAP_LINEAR);
	texture->setFilter(osg::Texture::FilterParameter::MAG_FILTER, osg::Texture::FilterMode::LINEAR);
	texture->setWrap(osg::Texture::WRAP_S, osg::Texture::WrapMode::REPEAT);
	texture->setWrap(osg::Texture::WRAP_T, osg::Texture::WrapMode::REPEAT);

	// rakjuk be egy geode-ba a quad-ot, mint kirajzoland� elemet!
	osg::ref_ptr<osg::Geode> root = new osg::Geode;
	root->addDrawable(quad.get());
	root->getOrCreateStateSet()->setTextureAttributeAndModes(0, texture.get());

	return root;
}

osg::Vec3 cylinderUV(float u, float v)
{
	u *= osg::PI * 2.0f;
	return osg::Vec3(cos(u), sin(u), v);
}
osg::Vec3 cylinderUVn(float u, float v)
{
	u *= osg::PI * 2.0f;
	return osg::Vec3(-cos(u), -sin(u), 0);
}
osg::Vec2 cylinderUVt(float u, float v)
{
	return osg::Vec2(u,v);
}

osg::Vec3 circleUV(float u, float v)
{
	u *= osg::PI * 2.0f;
	return osg::Vec3(cos(u)*v, sin(u)*v, v*0);
}
osg::Vec3 circleUVn(float u, float v)
{
	return osg::Vec3(0,0,-1);
}
osg::Vec2 circleUVt(float u, float v)
{
	return osg::Vec2(u, v);
}

osg::ref_ptr<osg::MatrixTransform> getHenger()
{
	//palast
	osg::ref_ptr<osg::MatrixTransform> ret = new osg::MatrixTransform;
	auto pala = getParam(cylinderUV, cylinderUVn, cylinderUVt);
	ret->addChild(pala.get());
	//kor
	auto kor = getParam(circleUV, circleUVn, circleUVt);
	
	osg::ref_ptr<osg::MatrixTransform> eltol = new osg::MatrixTransform;
	eltol->setMatrix(osg::Matrix::translate(osg::Vec3(0, 0, 1)));

	eltol->addChild(kor.get());
	ret->addChild(eltol.get());

	osg::ref_ptr<osg::MatrixTransform> elforgat = new osg::MatrixTransform;
	elforgat->setMatrix(osg::Matrix::rotate(osg::PI,0,1,0));
	elforgat->addChild(kor.get());
	ret->addChild(elforgat.get());

	return ret;
}

int main(int argc, char** argv)
{
	auto hengert = getHenger();
	osg::ref_ptr<osg::MatrixTransform> trafo1 = new osg::MatrixTransform;
	trafo1->setMatrix(osg::Matrix::scale(osg::Vec3(1, 1, 1 / 3.f))
					*osg::Matrix::translate(0,0,4));
	osg::ref_ptr<osg::MatrixTransform> trafo2 = new osg::MatrixTransform;
	trafo2->setMatrix(osg::Matrix::scale(osg::Vec3(0.5, 0.5, 4)));
	osg::ref_ptr<osg::MatrixTransform> feszek = new osg::MatrixTransform;
	feszek->addChild(trafo1.get());
	feszek->addChild(trafo2.get());
	trafo1->addChild(hengert.get());
	trafo2->addChild(hengert.get());

	osgDB::writeNodeFile(*(feszek.get()), "feszek.obj");
	
	osg::StateSet* state = feszek->getOrCreateStateSet();
	state->setMode(GL_LIGHTING,
		osg::StateAttribute::ON |
		osg::StateAttribute::PROTECTED);
	// 0-�s mintav�telez�re rakjuk r� a text�r�t


	// hozzuk l�tre a viewer-t �s �ll�tsuk be a gy�keret megjelen�tend� adatnak
	osgViewer::Viewer viewer;
	viewer.setSceneData(feszek.get());

	// a (20,20) kezdeti poz�ci�ba hozzunk l�tre egy 640x480-as ablakot
	viewer.setUpViewInWindow(20, 20, 640, 480);
	viewer.realize();

	// adjuk �t a vez�rl�st a viewer-nek
	return viewer.run();
}