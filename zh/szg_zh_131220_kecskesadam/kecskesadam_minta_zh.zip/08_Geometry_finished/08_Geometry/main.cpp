#include <osg/Texture2D>
#include <osg/Geometry>
#include <osgDB/ReadFile>
#include <osgDB/WriteFile>
#include <osgViewer/Viewer>
#include <osg/PolygonMode>
#include <osg/MatrixTransform>

#include <string>

#ifdef _DEBUG
#pragma comment(lib, "osgd.lib")
#pragma comment(lib, "osgDBd.lib")
#pragma comment(lib, "osgViewerd.lib")
#else
#pragma comment(lib, "osg.lib")
#pragma comment(lib, "osgDB.lib")
#pragma comment(lib, "osgViewer.lib")
#endif

#pragma warning(disable : 4482 )

osg::Vec3 ZeroY(osg::Vec3 vec) {
	return osg::Vec3(vec[0], 0, vec[2]);
}

osg::ref_ptr<osg::Geometry> CreateCylinder() {

	osg::ref_ptr<osg::Geometry> cylinder = new osg::Geometry;
	//

	// poz�ci�k
	osg::ref_ptr<osg::Vec3Array> vertices = new osg::Vec3Array;
	// norm�lisok
	osg::ref_ptr<osg::Vec3Array> normals = new osg::Vec3Array;
	// Text�ra koordin�t�k
	osg::ref_ptr<osg::Vec2Array> texarray = new osg::Vec2Array;

	// �ssze�ll�t�s
	int detail = 12;
	float step = 360 / float(detail) / 180.f * 3.1415f;

	// fels� lap
	osg::Vec3 top = osg::Vec3(0, 0.5, 0);
	for (int i = 0; i < detail; i++) {

		int ni = (i + 1) % detail;

		osg::Vec3 prev = osg::Vec3(cos(i*step), 0.5, sin(i*step));
		osg::Vec3 next = osg::Vec3(cos(ni*step), 0.5, sin(ni*step));

		vertices->push_back(top);
		vertices->push_back(next);
		vertices->push_back(prev);

		normals->push_back(osg::Vec3(0, 1, 0));
		normals->push_back(osg::Vec3(0, 1, 0));
		normals->push_back(osg::Vec3(0, 1, 0));

		texarray->push_back(osg::Vec2(0.5, 0.5));
		texarray->push_back(osg::Vec2(next[0] *0.5 + 0.5, next[2]*0.5 + 0.5));
		texarray->push_back(osg::Vec2(prev[0]*0.5+0.5, prev[2]*0.5 + 0.5));

	}


	// als� lap
	osg::Vec3 bot = osg::Vec3(0, -0.5, 0);
	for (int i = 0; i < detail; i++) {

		int ni = (i + 1) % detail;

		osg::Vec3 prev = osg::Vec3(cos(i*step), -0.5, sin(i*step));
		osg::Vec3 next = osg::Vec3(cos(ni*step), -0.5, sin(ni*step));

		vertices->push_back(bot);
		vertices->push_back(prev);
		vertices->push_back(next);

		normals->push_back(osg::Vec3(0, -1, 0));
		normals->push_back(osg::Vec3(0, -1, 0));
		normals->push_back(osg::Vec3(0, -1, 0));

		texarray->push_back(osg::Vec2(0.5, 0.5));
		texarray->push_back(osg::Vec2(prev[0] * 0.5 + 0.5, prev[2] * 0.5 + 0.5));
		texarray->push_back(osg::Vec2(next[0] * 0.5 + 0.5, next[2] * 0.5 + 0.5));

	}

	// pal�st

	for (int i = 0; i < detail; i++) {
		int ni = (i + 1) % detail;

		float u = float(i) / float(detail);
		float un = float(i+1) / float(detail);

		osg::Vec3 prev_bot = osg::Vec3(cos(i*step), -0.5, sin(i*step));
		osg::Vec3 next_bot = osg::Vec3(cos(ni*step), -0.5, sin(ni*step));
		osg::Vec3 prev_top = osg::Vec3(cos(i*step), 0.5, sin(i*step));
		osg::Vec3 next_top = osg::Vec3(cos(ni*step), 0.5, sin(ni*step));

		// tri 1
		vertices->push_back(prev_bot);
		vertices->push_back(prev_top);
		vertices->push_back(next_bot);

		normals->push_back(ZeroY(prev_bot));
		normals->push_back(ZeroY(prev_top));
		normals->push_back(ZeroY(next_bot));

		texarray->push_back(osg::Vec2(u, 0));
		texarray->push_back(osg::Vec2(u, 1));
		texarray->push_back(osg::Vec2(un, 0));

		// tri 2

		vertices->push_back(next_bot);
		vertices->push_back(prev_top);
		vertices->push_back(next_top);

		normals->push_back(ZeroY(next_bot));
		normals->push_back(ZeroY(prev_top));
		normals->push_back(ZeroY(next_top));

		texarray->push_back(osg::Vec2(un, 0));
		texarray->push_back(osg::Vec2(u, 1));
		texarray->push_back(osg::Vec2(un, 1));

	}

	//

	// azt akarjuk, h VBO-ban t�rolja az OSG a geometri�nkat, ehhez
	// ki kell kapcsolni a display list-es (elavult OGL-es) t�mogat�st ( setUseDisplayList(false) )
	// �s k�l�n meg kell k�rni a VBO haszn�latot ( setUseVertexBufferObjects(true) )
	cylinder->setUseDisplayList(false);
	cylinder->setUseVertexBufferObjects(true);
	// �s most hat�rozzuk meg, hogy a poz�ci�, norm�lis �s sz�nadatok honnan j�jjenek:

	// a poz�ci� adatok a vertices t�mbb�l
	cylinder->setVertexArray(vertices.get());

	// a norm�lisok a normals t�mbb�l
	cylinder->setNormalArray(normals.get());
	// �gy, hogy a normals t�mb minden egyes cs�csponthoz k�l�n t�rolja a norm�lisokat
	cylinder->setNormalBinding(osg::Geometry::BIND_PER_VERTEX);

	// texarray-b�l j�jjenek a text�ra koordin�t�k
	cylinder->setTexCoordArray(0, texarray.get());

	// kirajzoland� primit�v meghat�roz�sa
	cylinder->addPrimitiveSet(new osg::DrawArrays(GL_TRIANGLES, 0, 4*detail*3));

	//
	return cylinder;

}

osg::ref_ptr<osg::Geometry> CreateCube() {

	osg::ref_ptr<osg::Geometry> cube = new osg::Geometry;
	//

	// poz�ci�k
	osg::ref_ptr<osg::Vec3Array> vertices = new osg::Vec3Array;
	// norm�lisok
	osg::ref_ptr<osg::Vec3Array> normals = new osg::Vec3Array;
	// Text�ra koordin�t�k
	osg::ref_ptr<osg::Vec2Array> texarray = new osg::Vec2Array;


	// els� lap
	{

		vertices->push_back(osg::Vec3(-1, -1, 1));
		vertices->push_back(osg::Vec3( 1, -1, 1));
		vertices->push_back(osg::Vec3(-1,  1, 1));


		vertices->push_back(osg::Vec3(-1,  1, 1));
		vertices->push_back(osg::Vec3( 1, -1, 1));
		vertices->push_back(osg::Vec3( 1,  1, 1));


		for (int i = 0; i < 6; i++) {
			normals->push_back(osg::Vec3(0,0,1));
		}

		texarray->push_back(osg::Vec2(0, 0));
		texarray->push_back(osg::Vec2(1, 0));
		texarray->push_back(osg::Vec2(0, 1));

		texarray->push_back(osg::Vec2(0, 1));
		texarray->push_back(osg::Vec2(1, 0));
		texarray->push_back(osg::Vec2(1, 1));

	}

	// h�ts� lap
	{

		vertices->push_back(osg::Vec3(-1, -1, -1));
		vertices->push_back(osg::Vec3(-1,  1, -1));
		vertices->push_back(osg::Vec3( 1, -1, -1));


		vertices->push_back(osg::Vec3(-1,  1, -1));
		vertices->push_back(osg::Vec3( 1,  1, -1));
		vertices->push_back(osg::Vec3( 1, -1, -1));


		for (int i = 0; i < 6; i++) {
			normals->push_back(osg::Vec3(0,0,-1));
		}

		texarray->push_back(osg::Vec2(0, 0));
		texarray->push_back(osg::Vec2(0, 1));
		texarray->push_back(osg::Vec2(1, 0));

		texarray->push_back(osg::Vec2(0, 1));
		texarray->push_back(osg::Vec2(1, 1));
		texarray->push_back(osg::Vec2(1, 0));

	}

	// bal lap
	{

		vertices->push_back(osg::Vec3(-1, -1, -1));
		vertices->push_back(osg::Vec3(-1, -1,  1));
		vertices->push_back(osg::Vec3(-1,  1, -1));


		vertices->push_back(osg::Vec3(-1,  1, -1));
		vertices->push_back(osg::Vec3(-1, -1,  1));
		vertices->push_back(osg::Vec3(-1,  1,  1));


		for (int i = 0; i < 6; i++) {
			normals->push_back(osg::Vec3(-1,0,0));
		}

		texarray->push_back(osg::Vec2(0, 0));
		texarray->push_back(osg::Vec2(1, 0));
		texarray->push_back(osg::Vec2(0, 1));

		texarray->push_back(osg::Vec2(0, 1));
		texarray->push_back(osg::Vec2(1, 0));
		texarray->push_back(osg::Vec2(1, 1));

	}

	// jobb lap
	{

		vertices->push_back(osg::Vec3(1, -1, -1));
		vertices->push_back(osg::Vec3(1,  1, -1));
		vertices->push_back(osg::Vec3(1, -1,  1));


		vertices->push_back(osg::Vec3(1,  1, -1));
		vertices->push_back(osg::Vec3(1,  1,  1));
		vertices->push_back(osg::Vec3(1, -1,  1));


		for (int i = 0; i < 6; i++) {
			normals->push_back(osg::Vec3(1,0,0));
		}

		texarray->push_back(osg::Vec2(0, 0));
		texarray->push_back(osg::Vec2(0, 1));
		texarray->push_back(osg::Vec2(1, 0));

		texarray->push_back(osg::Vec2(0, 1));
		texarray->push_back(osg::Vec2(1, 1));
		texarray->push_back(osg::Vec2(1, 0));

	}
	
	// als� lap
	{

		vertices->push_back(osg::Vec3(-1,  -1, -1));
		vertices->push_back(osg::Vec3( 1,  -1, -1));
		vertices->push_back(osg::Vec3(-1,  -1,  1));


		vertices->push_back(osg::Vec3(-1,  -1,  1));
		vertices->push_back(osg::Vec3( 1,  -1, -1));
		vertices->push_back(osg::Vec3( 1,  -1,  1));


		for (int i = 0; i < 6; i++) {
			normals->push_back(osg::Vec3(0,-1,0));
		}

		texarray->push_back(osg::Vec2(0, 0));
		texarray->push_back(osg::Vec2(1, 0));
		texarray->push_back(osg::Vec2(0, 1));

		texarray->push_back(osg::Vec2(0, 1));
		texarray->push_back(osg::Vec2(1, 0));
		texarray->push_back(osg::Vec2(1, 1));

	}

	// fels� lap
	{

		vertices->push_back(osg::Vec3(-1, 1, -1));
		vertices->push_back(osg::Vec3(-1, 1,  1));
		vertices->push_back(osg::Vec3( 1, 1, -1));


		vertices->push_back(osg::Vec3(-1, 1,  1));
		vertices->push_back(osg::Vec3( 1, 1,  1));
		vertices->push_back(osg::Vec3( 1, 1, -1));


		for (int i = 0; i < 6; i++) {
			normals->push_back(osg::Vec3(0,1,0));
		}

		texarray->push_back(osg::Vec2(0, 0));
		texarray->push_back(osg::Vec2(0, 1));
		texarray->push_back(osg::Vec2(1, 0));

		texarray->push_back(osg::Vec2(0, 1));
		texarray->push_back(osg::Vec2(1, 1));
		texarray->push_back(osg::Vec2(1, 0));

	}


	//
	// azt akarjuk, h VBO-ban t�rolja az OSG a geometri�nkat, ehhez
	// ki kell kapcsolni a display list-es (elavult OGL-es) t�mogat�st ( setUseDisplayList(false) )
	// �s k�l�n meg kell k�rni a VBO haszn�latot ( setUseVertexBufferObjects(true) )
	cube->setUseDisplayList(false);
	cube->setUseVertexBufferObjects(true);
	// �s most hat�rozzuk meg, hogy a poz�ci�, norm�lis �s sz�nadatok honnan j�jjenek:

	// a poz�ci� adatok a vertices t�mbb�l
	cube->setVertexArray(vertices.get());

	// a norm�lisok a normals t�mbb�l
	cube->setNormalArray(normals.get());
	// �gy, hogy a normals t�mb minden egyes cs�csponthoz k�l�n t�rolja a norm�lisokat
	cube->setNormalBinding(osg::Geometry::BIND_PER_VERTEX);

	// texarray-b�l j�jjenek a text�ra koordin�t�k
	cube->setTexCoordArray(0, texarray.get());

	// kirajzoland� primit�v meghat�roz�sa
	cube->addPrimitiveSet(new osg::DrawArrays(GL_TRIANGLES, 0, 6*2*3));

	//
	return cube;

}

osg::ref_ptr<osg::Geode> WrapGeometry(osg::ref_ptr<osg::Geometry> geom) {

	osg::ref_ptr<osg::Geode> root = new osg::Geode;

	// rakjuk be egy geode-ba a kirajzoland� elemet!
	root->addDrawable(geom.get());

	// a h�trafel� n�z� lapokat rajzoljuk ki vonalasan csak
	osg::ref_ptr<osg::PolygonMode> pm = new osg::PolygonMode;
	pm->setMode(osg::PolygonMode::BACK,
		osg::PolygonMode::LINE);
	root->getOrCreateStateSet()->setAttribute(pm.get());

	root->getOrCreateStateSet()->setMode(GL_NORMALIZE, osg::StateAttribute::ON);

	return root;

}

void TextureNode(osg::ref_ptr<osg::Node> node, std::string path) {

	// text�ra bet�lt�se
	osg::ref_ptr<osg::Texture2D> texture = new osg::Texture2D;
	//osg::ref_ptr<osg::Image> image = osgDB::readImageFile("Images/moon256128.TGA");
	osg::ref_ptr<osg::Image> image = osgDB::readImageFile(path);
	texture->setImage(image.get());
	texture->setFilter(osg::Texture::FilterParameter::MIN_FILTER, osg::Texture::FilterMode::LINEAR_MIPMAP_LINEAR);
	texture->setFilter(osg::Texture::FilterParameter::MAG_FILTER, osg::Texture::FilterMode::LINEAR);
	texture->setWrap(osg::Texture::WRAP_S, osg::Texture::WrapMode::REPEAT);
	texture->setWrap(osg::Texture::WRAP_T, osg::Texture::WrapMode::REPEAT);

	// 0-�s mintav�telez�re rakjuk r� a text�r�t
	node->getOrCreateStateSet()->setTextureAttributeAndModes(0, texture.get());
}

int main(int argc, char** argv)
{


	// geometria
	osg::ref_ptr<osg::Geode> cube = WrapGeometry(CreateCube());
	osg::ref_ptr<osg::Geode> cylinder = WrapGeometry(CreateCylinder());

	/////////////////////////////////////////////////

	// rep�l�
	osg::ref_ptr<osg::Group> fecske = new osg::Group;

	// rep�l� test
	osg::ref_ptr<osg::MatrixTransform> test = new osg::MatrixTransform;
	test->setMatrix(
		osg::Matrix::scale(osg::Vec3(0.5,4,0.5))* // egys�g �tm�r�j� = f�l egys�g sugar�
		osg::Matrix::rotate(3.14 / 2, osg::Vec3(1, 0, 0))
	);
	test->addChild(cylinder);
	fecske->addChild(test);

	// faroksz�rny
	osg::ref_ptr<osg::MatrixTransform> farokszarny = new osg::MatrixTransform;
	farokszarny->setMatrix(
		osg::Matrix::scale(osg::Vec3(0.5*0.5, 0.5*1.5, 0.5)) *
		osg::Matrix::translate(osg::Vec3(0,1,-1.25))
	);
	farokszarny->addChild(cube);
	fecske->addChild(farokszarny);

	// sz�rny
	osg::ref_ptr<osg::MatrixTransform> szarny = new osg::MatrixTransform;
	szarny->setMatrix(
		osg::Matrix::scale(osg::Vec3(1, 0.5*(1.0/3.0), 0.5))
	);
	szarny->addChild(cube);

	// bal sz�rny
	osg::ref_ptr<osg::MatrixTransform> bal_szarny = new osg::MatrixTransform;
	bal_szarny->setMatrix(
		osg::Matrix::translate(osg::Vec3(1.5, 0, 0.5))
	);
	bal_szarny->addChild(szarny);
	fecske->addChild(bal_szarny);

	// jobb sz�rny
	osg::ref_ptr<osg::MatrixTransform> jobb_szarny = new osg::MatrixTransform;
	jobb_szarny->setMatrix(
		osg::Matrix::translate(osg::Vec3(-1.5, 0, 0.5))
	);
	jobb_szarny->addChild(szarny);
	fecske->addChild(jobb_szarny);

	/////////////////////////////////////////////////

	// torony
	osg::ref_ptr<osg::Group> feszek = new osg::Group;

	// antenna test
	osg::ref_ptr<osg::MatrixTransform> a_test = new osg::MatrixTransform;
	a_test->setMatrix(
		osg::Matrix::translate(osg::Vec3(0,0.5,0))*
		osg::Matrix::scale(osg::Vec3(0.5, 4, 0.5))
	);
	a_test->addChild(cylinder);
	feszek->addChild(a_test);

	// antenna tet�
	osg::ref_ptr<osg::MatrixTransform> teto = new osg::MatrixTransform;
	teto->setMatrix(
		osg::Matrix::scale(osg::Vec3(1, 1.0/3.0, 1))*
		osg::Matrix::translate(osg::Vec3(0, 4, 0))
	);
	teto->addChild(cylinder);
	feszek->addChild(teto);

	/////////////////////////////////////////////////

	TextureNode(fecske, "blue.bmp");
	TextureNode(feszek, "purple.bmp");

	/////////////////////////////////////////////////

	// hozzuk l�tre a viewer-t �s �ll�tsuk be a gy�keret megjelen�tend� adatnak
	osgViewer::Viewer viewer;
	viewer.setSceneData(fecske.get());

	// a (20,20) kezdeti poz�ci�ba hozzunk l�tre egy 640x480-as ablakot
	viewer.setUpViewInWindow(30, 30, 640, 480);
	viewer.realize();

	// export
	osgDB::writeNodeFile(*(fecske.get()), "fecske.obj");
	osgDB::writeNodeFile(*(feszek.get()), "feszek.obj");

	// adjuk �t a vez�rl�st a viewer-nek
	return viewer.run();
}