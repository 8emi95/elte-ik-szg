#include "MyApp.h"
#include "GLUtils.hpp"

#include <GL/GLU.h>
#include <math.h>

#include "ObjParser_OGL3.h"

CMyApp::CMyApp(void)
{
	m_fecske_mesh = nullptr;
	m_feszek_mesh = nullptr;
}


CMyApp::~CMyApp(void)
{
}


bool CMyApp::Init()
{
	// t�rl�si sz�n legyen k�kes
	glClearColor(0.125f, 0.25f, 0.5f, 1.0f);

	glEnable(GL_CULL_FACE);		// kapcsoljuk be a hatrafele nezo lapok eldobasat
	glEnable(GL_DEPTH_TEST);	// m�lys�gi teszt bekapcsol�sa (takar�s)

	//
	// geometria letrehozasa
	//
	m_vb.AddAttribute(0, 3);
	m_vb.AddAttribute(1, 3);
	m_vb.AddAttribute(2, 2);

	m_vb.AddData(0, -10,  0, -10);
	m_vb.AddData(0,  10,  0, -10);
	m_vb.AddData(0, -10,  0,  10);
	m_vb.AddData(0,  10,  0,  10);

	m_vb.AddData(1, 0, 1, 0);
	m_vb.AddData(1, 0, 1, 0);
	m_vb.AddData(1, 0, 1, 0);
	m_vb.AddData(1, 0, 1, 0);

	m_vb.AddData(2, 0, 0);
	m_vb.AddData(2, 1, 0);
	m_vb.AddData(2, 0, 1);
	m_vb.AddData(2, 1, 1);

	m_vb.AddIndex(1, 0, 2);
	m_vb.AddIndex(1, 2, 3);

	m_vb.InitBuffers();

	//
	// shaderek bet�lt�se
	//
	m_program.AttachShader(GL_VERTEX_SHADER, "dirLight.vert");
	m_program.AttachShader(GL_FRAGMENT_SHADER, "dirLight.frag");

	m_program.BindAttribLoc(0, "vs_in_pos");
	m_program.BindAttribLoc(1, "vs_in_normal");
	m_program.BindAttribLoc(2, "vs_in_tex0");

	if ( !m_program.LinkProgram() )
	{
		return false;
	}

	//
	// egy�b inicializ�l�s
	//

	m_camera.SetProj(45.0f, 640.0f/480.0f, 0.01f, 1000.0f);

	// text�ra bet�lt�se
	m_ground_textureID = TextureFromFile("ground.jpg");
	m_blue_textureID = TextureFromFile("blue.bmp");
	m_purple_textureID = TextureFromFile("purple.bmp");

	// mesh bet�lt�s
	m_fecske_mesh = ObjParser::parse("fecske.obj");
	m_fecske_mesh->initBuffers();

	m_feszek_mesh = ObjParser::parse("feszek.obj");
	m_feszek_mesh->initBuffers();

	for (int i = 1; i <= 5; i++) {
		fecskek.push_back(FecskeState(i));
	}

	return true;
}

void CMyApp::Clean()
{
	glDeleteTextures(1, &m_ground_textureID);
	glDeleteTextures(1, &m_blue_textureID);
	glDeleteTextures(1, &m_purple_textureID);

	m_program.Clean();
}

void CMyApp::Update()
{
	static Uint32 last_time = SDL_GetTicks();
	float delta_time = (SDL_GetTicks() - last_time)/1000.0f;

	m_camera.Update(delta_time);

	last_time = SDL_GetTicks();

	for (int i = 0; i < 5; i++) {

		FecskeState& fecske = fecskek[i];

		switch(fecske.state) {

		case FlyState::Takeoff:

			if (last_time - fecske.time > 1000) {

				bool is_flying = false;
				for (FecskeState& fecske2 : fecskek) {
					if (fecske2.state == FlyState::Fly) {
						is_flying = true;
					}
				}

				if (is_flying) {
					fecske.state = FlyState::Land;
				} else {
					fecske.state = FlyState::Fly;
				}

				fecske.time = last_time;
			}
			break;

		case FlyState::Land:

			if (last_time - fecske.time > 1000) {
				fecske.state = FlyState::None;
				fecske.time = last_time;
			}
			break;

		case FlyState::Fly:

			if (last_time - fecske.time > fecske.fly_time*1000) {
				fecske.state = FlyState::Land;
				fecske.time = last_time;
			}
			break;

		}

	}

}


void CMyApp::Render()
{
	// t�r�lj�k a frampuffert (GL_COLOR_BUFFER_BIT) �s a m�lys�gi Z puffert (GL_DEPTH_BUFFER_BIT)
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	m_program.On();

	glm::mat4 matWorld = glm::mat4(1.0f);
	glm::mat4 matWorldIT = glm::transpose( glm::inverse( matWorld ) );
	glm::mat4 mvp = m_camera.GetViewProj() *matWorld;

	m_program.SetUniform( "world", matWorld );
	m_program.SetUniform( "worldIT", matWorldIT );
	m_program.SetUniform( "MVP", mvp );
	m_program.SetUniform( "eye_pos", m_camera.GetEye() );

	m_program.SetTexture("texImage", 0, m_ground_textureID);

	// kapcsoljuk be a VAO-t (a VBO j�n vele egy�tt)
	m_vb.On();

	m_vb.DrawIndexed(GL_TRIANGLES, 0, 6, 0);

	m_vb.Off();

	// shader kikapcsolasa
	m_program.Off();

	// 2. program
	m_program.On();

	matWorld = glm::translate( glm::vec3(0, 0, 0) );
	matWorldIT = glm::transpose( glm::inverse( matWorld ) );
	mvp = m_camera.GetViewProj() *matWorld;

	m_program.SetUniform( "world", matWorld );
	m_program.SetUniform( "worldIT", matWorldIT );
	m_program.SetUniform( "MVP", mvp );
	m_program.SetUniform( "eye_pos", m_camera.GetEye() );

	m_program.SetTexture("texImage", 0, m_purple_textureID);

	m_feszek_mesh->draw();

	m_program.SetTexture("texImage", 0, m_blue_textureID);

	Uint32 now = SDL_GetTicks();

	for (int i = 0; i < 5; i++) {

		FecskeState fecske = fecskek[i];

		float take_proc;

		switch (fecske.state) {

		case FlyState::Fly:
			
			matWorld =  glm::rotate((float(i) / 5 + float(now-fecske.time)/(1000.f*fecske.fly_time)) * 3.1415f * 2.f, glm::vec3(0, 1, 0)) *
						glm::translate(glm::vec3(0, 2, -5)) *
						glm::rotate(-0.5f * 3.1415f, glm::vec3(0, 1, 0));
			break;

		case FlyState::Takeoff:

			take_proc = float(now - fecske.time) / 1000.f;

			matWorld =  glm::rotate(float(i) / 5 * 3.1415f * 2.f, glm::vec3(0, 1, 0)) *
						glm::translate(glm::vec3(0, 2.f*take_proc, -5)) *
						glm::rotate(-take_proc * 0.5f * 3.1415f, glm::vec3(0, 1, 0));
			break;

		case FlyState::Land:

			take_proc = 1.f - float(now - fecske.time) / 1000.f;

			matWorld =  glm::rotate(float(i) / 5 * 3.1415f * 2.f, glm::vec3(0, 1, 0)) *
						glm::translate(glm::vec3(0, 2.f*take_proc, -5)) *
						glm::rotate(-take_proc * 0.5f * 3.1415f, glm::vec3(0, 1, 0));
			break;

		case FlyState::None:
		default:

			matWorld = glm::rotate(float(i) / 5 * 3.1415f * 2.f, glm::vec3(0, 1, 0))*glm::translate(glm::vec3(0, 0, -5));
			break;

		}

		matWorldIT = glm::transpose(glm::inverse(matWorld));
		mvp = m_camera.GetViewProj() *matWorld;

		m_program.SetUniform("world", matWorld);
		m_program.SetUniform("worldIT", matWorldIT);
		m_program.SetUniform("MVP", mvp);

		m_fecske_mesh->draw();

	}

	m_program.Off();
}

void CMyApp::KeyboardDown(SDL_KeyboardEvent& key)
{
	m_camera.KeyboardDown(key);
}

void CMyApp::KeyboardUp(SDL_KeyboardEvent& key)
{
	m_camera.KeyboardUp(key);

	int findex = -1;
	switch (key.keysym.sym) {
	case SDLK_1:
		findex = 0;
		break;
	case SDLK_2:
		findex = 1;
		break;
	case SDLK_3:
		findex = 2;
		break;
	case SDLK_4:
		findex = 3;
		break;
	case SDLK_5:
		findex = 4;
		break;
	}

	if (findex > -1 && fecskek[findex].state == FlyState::None) {
		fecskek[findex].state = FlyState::Takeoff;
		fecskek[findex].time = SDL_GetTicks();
	}

}

void CMyApp::MouseMove(SDL_MouseMotionEvent& mouse)
{
	m_camera.MouseMove(mouse);
}

void CMyApp::MouseDown(SDL_MouseButtonEvent& mouse)
{
}

void CMyApp::MouseUp(SDL_MouseButtonEvent& mouse)
{
}

void CMyApp::MouseWheel(SDL_MouseWheelEvent& wheel)
{
}

// a k�t param�terbe az �j ablakm�ret sz�less�ge (_w) �s magass�ga (_h) tal�lhat�
void CMyApp::Resize(int _w, int _h)
{
	glViewport(0, 0, _w, _h);

	m_camera.Resize(_w, _h);
}