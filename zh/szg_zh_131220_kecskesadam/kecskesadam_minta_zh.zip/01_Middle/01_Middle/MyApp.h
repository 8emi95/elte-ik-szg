#pragma once

// GLEW
#include <GL/glew.h>

// SDL
#include <SDL.h>
#include <SDL_opengl.h>

// GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform2.hpp>

#include "gCamera.h"
#include "gShaderProgram.h"
#include "gVertexBuffer.h"
#include "Mesh_OGL3.h"

#include <vector>

class CMyApp
{
public:
	CMyApp(void);
	~CMyApp(void);

	bool Init();
	void Clean();

	void Update();
	void Render();

	void KeyboardDown(SDL_KeyboardEvent&);
	void KeyboardUp(SDL_KeyboardEvent&);
	void MouseMove(SDL_MouseMotionEvent&);
	void MouseDown(SDL_MouseButtonEvent&);
	void MouseUp(SDL_MouseButtonEvent&);
	void MouseWheel(SDL_MouseWheelEvent&);
	void Resize(int, int);
protected:

	// OpenGL-es dolgok
	GLuint m_ground_textureID; // text�ra er�forr�s azonos�t�
	GLuint m_blue_textureID;
	GLuint m_purple_textureID;

	gCamera			m_camera;
	gShaderProgram	m_program;
	gVertexBuffer	m_vb;

	Mesh			*m_fecske_mesh;
	Mesh			*m_feszek_mesh;

	enum FlyState {
		None,
		Takeoff,
		Fly,
		Land
	};

	struct FecskeState {
		FlyState state = FlyState::None;
		Uint32 time = 0;
		int fly_time;

		FecskeState(int time) : fly_time(time) {}

	};

	std::vector<FecskeState> fecskek;

};

